Open File "FaceDetectionLive.py"

Model in "Main.py"